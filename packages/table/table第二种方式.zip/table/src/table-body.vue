<template>
	<table 
		class="el-table__body"
		cellspacing="0"
		cellpadding="0"
		border="0">
		<colgroup>
          <col v-for="col in columns" 
          	:key="col.id"
          	:name="col.id"
          	:width="col.width"/>
        </colgroup>
        <tbody
        	@click="handleClick"
        	@dblclick="handleDoubleClick"
        	@contextmenu="handleContextMenu">
        	<tr v-for="(row,$index) in data"
        		:style="trStyle(row, $index)"
        		:key="trKey(row, $index)"
        		@mouseenter="handleMouseEnter($index)"
        		@mouseleave="handleMouseLeave"
        		:class="trClass(row, $index)"
        		:index="$index">
        		<td v-for="(column,cellIndex) in columns"
        			v-if="getSpan(row, column, $index, cellIndex)"
        			:style="getCellStyle($index, cellIndex, row, column)"
        			:class="getCellClass($index, cellIndex, row, column)"
        			:rowspan="column._rowspan"
        			:colspan="column._colspan"
        			@mouseenter="handleCellMouseEnter($event, row)"
        			@mouseleave="handleCellMouseLeave">
        			<ElTableCell
			         	v-if="column.type=='selection'||column.type=='index'"
	    				:store="store"
	    				:config="config(row,column,$index)">
	    			</ElTableCell>
        			<div v-else-if="showTooltip" class="cell el-tooltip" :style="{width: (column.realWidth || column.width) - 1 + 'px'}">
        				<div v-if="realtype(column)=='select'">
			         		<div v-if="isHide(row)">{{row[column.keys]}}</div>
				         	<el-select
				         		v-else
				         		v-model="row[column.keys]" 
				         		size="mini" 
				         		v-show="row.edit">
							    <el-option
							      	v-for="item in column.config.options"
							      	:key="item.value"
							      	:label="item.label"
							      	:value="item.value">
							    </el-option>
						  	</el-select>
			         	</div>
			         	<div v-else-if="realtype(column)=='input'">
			         		<div v-if="isHide(row)">{{row[column.keys]}}</div>
				         	<el-input
				         		v-else
							  	type="input"
							  	size="mini"
							  	v-show="row.edit"
							  	v-model="row[column.keys]">
							</el-input>
			         	</div>
			         	<div v-else-if="realtype(column)=='textarea'">
			         		<div v-if="isHide(row)">{{row[column.keys]}}</div>
				         	<el-input
				         		v-else
							  	type="textarea"
							  	v-show="row.edit"
							  	v-model="row[column.keys]">
							</el-input>
			         	</div>
			         	<div v-else-if="realtype(column)=='date'">
			         		<div v-if="isHide(row)">{{row[column.keys]}}</div>
				         	<el-date-picker
				         		v-else
						      	type="date"
						      	size="mini"
						      	style="width: 130px;"
						      	v-show="row.edit"
						      	placeholder="选择日期"
						      	v-model="row[column.keys]"
						      	@blur="dateTrans(row,column.keys)">
						    </el-date-picker>
			         	</div>
			         	<div v-else-if="realtype(column)=='button'">
				         	<el-button
				         		v-if="btnShow(row,column.config.show)"
					          	size="mini"
					          	:type="column.config.theme"
					          	:disabled="btnDisable(row,column.config.disable)"
					          	@click="handleColumnBtnClick($event,column,$index)">{{column.config.text}}</el-button>
			         	</div>
			         	<div v-else-if="realtype(column)=='textbutton'">
			         		<div>{{row[column.keys]}}</div>
				         	<el-button
				         		v-if="btnShow(row,column.config.switch)"
					          	size="mini"
					          	:type="column.config.theme"
					          	:disabled="btnDisable(row,column.config.disable)"
					          	@click="handleColumnBtnClick($event,column,$index)">{{column.config.text}}</el-button>
			         	</div>
			         	<div v-else>
			         		{{row[column.keys]}}
			         	</div>
        			</div>
        			<div v-else class="cell">
        				<div v-if="realtype(column)=='select'">
			         		<div v-if="isHide(row)">{{row[column.keys]}}</div>
				         	<el-select
				         		v-else
				         		v-model="row[column.keys]" 
				         		size="mini" 
				         		v-show="row.edit">
							    <el-option
							      	v-for="item in column.config.options"
							      	:key="item.value"
							      	:label="item.label"
							      	:value="item.value">
							    </el-option>
						  	</el-select>
			         	</div>
			         	<div v-else-if="realtype(column)=='input'">
			         		<div v-if="isHide(row)">{{row[column.keys]}}</div>
				         	<el-input
				         		v-else
							  	type="input"
							  	size="mini"
							  	v-show="row.edit"
							  	v-model="row[column.keys]">
							</el-input>
			         	</div>
			         	<div v-else-if="realtype(column)=='textarea'">
			         		<div v-if="isHide(row)">{{row[column.keys]}}</div>
				         	<el-input
				         		v-else
							  	type="textarea"
							  	v-show="row.edit"
							  	v-model="row[column.keys]">
							</el-input>
			         	</div>
			         	<div v-else-if="realtype(column)=='date'">
			         		<div v-if="isHide(row)">{{row[column.keys]}}</div>
				         	<el-date-picker
				         		v-else
						      	type="date"
						      	size="mini"
						      	style="width: 130px;"
						      	v-show="row.edit"
						      	placeholder="选择日期"
						      	v-model="row[column.keys]"
						      	@blur="dateTrans(row,column.keys)">
						    </el-date-picker>
			         	</div>
			         	<div v-else-if="realtype(column)=='button'">
				         	<el-button
				         		v-if="btnShow(row,column.config.show)"
					          	size="mini"
					          	:type="column.config.theme"
					          	:disabled="btnDisable(row,column.config.disable)"
					          	@click="handleColumnBtnClick($event,column,$index)">{{column.config.text}}</el-button>
			         	</div>
			         	<div v-else-if="realtype(column)=='textbutton'">
			         		<div>{{row[column.keys]}}</div>
				         	<el-button
				         		v-if="btnShow(row,column.config.switch)"
					          	size="mini"
					          	:type="column.config.theme"
					          	:disabled="btnDisable(row,column.config.disable)"
					          	@click="handleColumnBtnClick($event,column,$index)">{{column.config.text}}</el-button>
			         	</div>
			         	<div v-else>
			         		{{row[column.keys]}}
			         	</div>
        			</div>
        		</td>
        	</tr>
        </tbody>
	</table>
</template>

<script>
	import { getCell, getColumnByCell, getRowIdentity } from './util';
	import { hasClass, addClass, removeClass } from 'element-ui/src/utils/dom';
	import ElCheckbox from 'element-ui/packages/checkbox';
	import ElTooltip from 'element-ui/packages/tooltip';
	import debounce from 'throttle-debounce/debounce';
	import LayoutObserver from './layout-observer';
	import ElTableCell from './cell';
	
	export default {
	  name: 'ElTableBody',
	
	  mixins: [LayoutObserver],
	
	  components: {
	    ElCheckbox,
	    ElTooltip,
	    ElTableCell
	  },
		
	  props: {
	    store: {
	      required: true
	    },
	    stripe: Boolean,
	    context: {},
	    rowClassName: [String, Function],
	    rowStyle: [Object, Function],
	    fixed: String,
	    highlight: Boolean
	  },
	
	  watch: {
	    'store.states.hoverRow'(newVal, oldVal) {
	      if (!this.store.states.isComplex) return;
	      const el = this.$el;
	      if (!el) return;
	      const tr = el.querySelector('tbody').children;
	      const rows = [].filter.call(tr, row => hasClass(row, 'el-table__row'));
	      const oldRow = rows[oldVal];
	      const newRow = rows[newVal];
	      if (oldRow) {
	        removeClass(oldRow, 'hover-row');
	      }
	      if (newRow) {
	        addClass(newRow, 'hover-row');
	      }
	    },
	    'store.states.currentRow'(newVal, oldVal) {
	      if (!this.highlight) return;
	      const el = this.$el;
	      if (!el) return;
	      const data = this.store.states.data;
	      const tr = el.querySelector('tbody').children;
	      const rows = [].filter.call(tr, row => hasClass(row, 'el-table__row'));
	      const oldRow = rows[data.indexOf(oldVal)];
	      const newRow = rows[data.indexOf(newVal)];
	      if (oldRow) {
	        removeClass(oldRow, 'current-row');
	      } else {
	        [].forEach.call(rows, row => removeClass(row, 'current-row'));
	      }
	      if (newRow) {
	        addClass(newRow, 'current-row');
	      }
	    }
	  },
	
	  computed: {
	    table() {
	      return this.$parent;
	    },
	
	    data() {
	      return this.store.states.data;
	    },
	
	    columnsCount() {
	      return this.store.states.columns.length;
	    },
	
	    leftFixedLeafCount() {
	      return this.store.states.fixedLeafColumnsLength;
	    },
	
	    rightFixedLeafCount() {
	      return this.store.states.rightFixedLeafColumnsLength;
	    },
	
	    leftFixedCount() {
	      return this.store.states.fixedColumns.length;
	    },
	
	    rightFixedCount() {
	      return this.store.states.rightFixedColumns.length;
	    },
	
	    columns() {
	      return this.store.states.columns;
	    },
	    
	    self(){
	    	return this.context || this.table.$vnode.context;
	    },
	    
	    showTooltip(){
	    	return this.self.showOverflowTooltip || this.self.showTooltipWhenOverflow;
	    }
	  },
	
	  data() {
	    return {
	      tooltipContent: ''
	    };
	  },
	
	  created() {
	    this.activateTooltip = debounce(50, tooltip => tooltip.handleShowPopper());
	  },
	
	  methods: {
	  	
	  	isHide(row){
	  		return !row.edit;
	  	},
	  	
	  	realtype(column){
	  		return column.config.type;
	  	},
	  	
	  	cbClick(ev){
	  		ev.stopPropagation();
	  	},
	  	
	  	cbInput(event,row){
	  		this.store.commit('rowSelectedChanged', row);
	  	},
	  	
	  	dateTrans(row,name){//时间选择框选择
    		//这里的格式现阶段默认是这样  如果需要改变需要传值定义
    		row[name]=row[name].Format("yyyy-MM-dd");
    	},
    	
    	isDisable(column, row, index){
	  		return column.selectable ? !column.selectable.call(null, row, index) : false ;
	  	},
	  	
	  	btnShow(row,name){
	  		if(name){if(row[name]){return true;}else{return false;}
	  		}else{return true;}
	  	},
	  	
	  	btnDisable(row,name){
	  		if(name){if(row[name]){return true;}else{return false;}
	  		}else{return false;}
	  	},
	  	
	  	config(row,column,$index){
	  		return {
	  			row,
	  			column,
	  			$index,
	            _self: this.context || this.table.$vnode.context,
	            columnsHidden:this.isColumnHidden($index),
	            renderProxy:this._renderProxy
	  		}
	  	},
	  	
	  	trStyle(row, $index){
	  		return this.rowStyle ? this.getRowStyle(row, $index) : null;
	  	},
	  	
	  	trKey(row, $index){
	  		return this.table.rowKey ? this.getKeyOfRow(row, $index) : $index;
	  	},
	  	
	  	trClass(row, $index){
	  		return [this.getRowClass(row, $index)];
	  	},
	  	
	    getKeyOfRow(row, index) {
	      const rowKey = this.table.rowKey;
	      if (rowKey) {
	        return getRowIdentity(row, rowKey);
	      }
	      return index;
	    },
	
	    isColumnHidden(index) {
	      if (this.fixed === true || this.fixed === 'left') {
	        return index >= this.leftFixedLeafCount;
	      } else if (this.fixed === 'right') {
	        return index < this.columnsCount - this.rightFixedLeafCount;
	      } else {
	        return (index < this.leftFixedLeafCount) || (index >= this.columnsCount - this.rightFixedLeafCount);
	      }
	    },
	
	    getSpan(row, column, rowIndex, columnIndex) {
	      let rowspan = 1;
	      let colspan = 1;
	
	      const fn = this.table.spanMethod;
	      if (typeof fn === 'function') {
	        const result = fn({
	          row,
	          column,
	          rowIndex,
	          columnIndex
	        });
	
	        if (Array.isArray(result)) {
	          rowspan = result[0];
	          colspan = result[1];
	        } else if (typeof result === 'object') {
	          rowspan = result.rowspan;
	          colspan = result.colspan;
	        }
	      }
	      if (!rowspan || !colspan) {
	      	return false;
	      }else{
	      	if(rowspan!=1||colspan!=1){
	      		column["_colspan"]=colspan;
	      		column["_rowspan"]=rowspan;
	      	}
	      	return true;
	      }
	    },
	
	    getRowStyle(row, rowIndex) {
	      const rowStyle = this.table.rowStyle;
	      if (typeof rowStyle === 'function') {
	        return rowStyle.call(null, {
	          row,
	          rowIndex
	        });
	      }
	      return rowStyle;
	    },
	
	    getRowClass(row, rowIndex) {
	      const classes = ['el-table__row'];
	
	      if (this.stripe && rowIndex % 2 === 1) {
	        classes.push('el-table__row--striped');
	      }
	      const rowClassName = this.table.rowClassName;
	      if (typeof rowClassName === 'string') {
	        classes.push(rowClassName);
	      } else if (typeof rowClassName === 'function') {
	        classes.push(rowClassName.call(null, {
	          row,
	          rowIndex
	        }));
	      }
	
	      if (this.store.states.expandRows.indexOf(row) > -1) {
	        classes.push('expanded');
	      }
	
	      return classes.join(' ');
	    },
	
	    getCellStyle(rowIndex, columnIndex, row, column) {
	      const cellStyle = this.table.cellStyle;
	      if (typeof cellStyle === 'function') {
	        return cellStyle.call(null, {
	          rowIndex,
	          columnIndex,
	          row,
	          column
	        });
	      }
	      return cellStyle;
	    },
	
	    getCellClass(rowIndex, columnIndex, row, column) {
	      const classes = [column.id, column.align, column.className];
	
	      if (this.isColumnHidden(columnIndex)) {
	        classes.push('is-hidden');
	      }
	
	      const cellClassName = this.table.cellClassName;
	      if (typeof cellClassName === 'string') {
	        classes.push(cellClassName);
	      } else if (typeof cellClassName === 'function') {
	        classes.push(cellClassName.call(null, {
	          rowIndex,
	          columnIndex,
	          row,
	          column
	        }));
	      }
	
	      return classes.join(' ');
	    },
	
	    handleCellMouseEnter(event, row) {
	      const table = this.table;
	      const cell = getCell(event);
	
	      if (cell) {
	        const column = getColumnByCell(table, cell);
	        const hoverState = table.hoverState = {cell, column, row};
	        table.$emit('cell-mouse-enter', hoverState.row, hoverState.column, hoverState.cell, event);
	      }
	
	      // 判断是否text-overflow, 如果是就显示tooltip
	      const cellChild = event.target.querySelector('.cell');
	
	      if (hasClass(cellChild, 'el-tooltip') && cellChild.scrollWidth > cellChild.offsetWidth && this.$refs.tooltip) {
	        const tooltip = this.$refs.tooltip;
	        // TODO 会引起整个 Table 的重新渲染，需要优化
	        this.tooltipContent = cell.textContent || cell.innerText;
	        tooltip.referenceElm = cell;
	        tooltip.$refs.popper && (tooltip.$refs.popper.style.display = 'none');
	        tooltip.doDestroy();
	        tooltip.setExpectedState(true);
	        this.activateTooltip(tooltip);
	      }
	    },
	
	    handleCellMouseLeave(event) {
	      const tooltip = this.$refs.tooltip;
	      if (tooltip) {
	        tooltip.setExpectedState(false);
	        tooltip.handleClosePopper();
	      }
	      const cell = getCell(event);
	      if (!cell) return;
	
	      const oldHoverState = this.table.hoverState || {};
	      this.table.$emit('cell-mouse-leave', oldHoverState.row, oldHoverState.column, oldHoverState.cell, event);
	    },
	
	    handleMouseEnter(index) {
	      this.store.commit('setHoverRow', index);
	    },
	
	    handleMouseLeave() {
	      this.store.commit('setHoverRow', null);
	    },
	    
	    handleColumnBtnClick(event,column,index){
	    	column.config.onTap.apply(this.table.$parent,arguments);
	    },
	
	    handleContextMenu(event) {
	      this.handleEvent(event, null, 'contextmenu');
	    },
	
	    handleDoubleClick(event) {
	      this.handleEvent(event, null, 'dblclick');
	    },
	
	    handleClick(event) {
	    	var target=this.getTarget(event.path);
	    	if(target){
	    		let index=parseInt(target.getAttribute("index"));
		    	var row=this.data[index];
				this.store.commit('setCurrentRow', row);
				this.handleEvent(event, row, 'click');
	    	}
	    },
		
		getTarget(path){
			for(let i=0,len=path.length;i<len;i++){
				if(path[i].nodeName&&path[i].nodeName.toLowerCase()=="tr"){
					return path[i];
				}
			}
			return null;
		},
		
	    handleEvent(event, row, name) {
		  if(!row){
	    	var target=this.getTarget(event.path);
	    	if(target){
	    		let index=parseInt(target.getAttribute("index"));
		    	row=this.data[index];
	    	}  
		  }
	      const table = this.table;
	      const cell = getCell(event);
	      let column;
	      if (cell) {
	        column = getColumnByCell(table, cell);
	        if (column) {
	          table.$emit(`cell-${name}`, row, column, cell, event);
	        }
	      }
	      table.$emit(`row-${name}`, row, event, column);
	    },
	
	    handleExpandClick(row, e) {
	      e.stopPropagation();
	      this.store.toggleRowExpansion(row);
	    }
	  }
	};
</script>